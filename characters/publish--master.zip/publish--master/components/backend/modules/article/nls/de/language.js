define({
	"navigation": "Artikel",
	"title": "Titel",
	"details": "Artikel Details",
    "author": "Autor",
    "article": "Artikel",
    "category": "Kategorie",
    "tags": "Tags",
    "teaser": "Einleitungstext",
    "categories": "Kategories",
    "emptyMessage": "Der Artikel existiert nicht mehr",
    "newArticle": "hat neuen Artikel erstellt",
    "deleteArticle": "hat Artikel gelöscht",
    "updateArticle": "hat Artikel bearbeitet"
});