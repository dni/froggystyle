define({
	"navigation": "Artikel",
	"defaultAuthor": "Standard Autor",
	"categories": "Kategorien"
});