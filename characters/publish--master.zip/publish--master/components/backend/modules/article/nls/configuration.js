define({
    "root": {
    	"navigation": "Articles",
        "defaultAuthor": "Default Author",
        "categories": "Categories"
    },
    "de": true
});