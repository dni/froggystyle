define({
    "root": {
    	"navigation": "Articles",
    	"details": "Article details",
        "title": "Title",
        "author": "Author",
        "teaser": "Teaser",
        "article": "Article",
        "category": "Category",
        "tags": "Tags",
        "emptyMessage": "The article does not exist anymore",
        "newArticle": "created new article",
        "deleteArticle": "deleted article",
        "updateArticle": "updated article"
    },
    "de": true
});