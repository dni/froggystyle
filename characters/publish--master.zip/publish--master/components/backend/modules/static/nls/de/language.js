define({
	"details": "Block Details",
	"navigation": "Statischer Block",
	"key": "Schlüssel",
	"data": "Inhalt",
	"emptyMessage": "Der statische Block existiert nicht mehr",
	"newStatic": "hat statischen Block erstellt",
	"deleteStatic": "hat statischen Block gelöscht",
	"updateStatic": "hat statischen Block aktuelisiert"
});