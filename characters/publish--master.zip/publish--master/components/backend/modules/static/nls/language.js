define({
    "root": {
    	"details": "Staticblock details",
    	"navigation": "Staticblocks",
    	"key": "Key",
    	"data": "Content",
        "emptyMessage": "The static block does not exist anymore",
        "newStatic": "created a new static block",
        "deleteStatic": "deleted static block",
        "updateStatic": "updated static block"
    },
    "de": true
});