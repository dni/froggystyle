define({
	"details": "Datei Details",
	"thumbnail": "Thumbnail Größe",
	"smallPic": "Kleine Bildgröße",
	"bigPic": "Große Bildgröße",
	"quality": "Bildqualität",
	"name": "Name",
	"addFiles": "Dateien hinzufügen...",
    "headline": "Dateien",
    "navigation": "Dateien",
	"info": "Info",
	"description": "Beschreibung",
	"alt": "Alternative Text",
	"filetype": "Dateityp",
    "emptyMessage": "Die Datei existiert nicht mehr",
    "newFile": "hat Datei hochgeladen",
    "deleteFile": "hat Datei gelöscht",
    "updateFile": "hat Datei bearbeitet"
});