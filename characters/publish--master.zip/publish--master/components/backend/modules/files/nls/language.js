define({
    "root": {
    	"details": "File details",
    	"thumbnail": "Thumbnail size",
    	"smallPic": "Small image size",
    	"bigPic": "Big image size",
    	"quality": "Image quality",
    	"addFiles": "Add files...",
    	"headline": "Files",
    	"navigation": "Files",
    	"name": "Name",
    	"info": "Info",
    	"description": "Description",
    	"alt": "Alt",
    	"filetype": "Filetype",
    	"fileDescription": "Use 'cover' and 'back' templates keys",
        "emptyMessage": "The file does not exist anymore",
        "newFile": "uploaded new file",
        "deleteFile": "deleted file",
        "updateFile": "updated file"
    },
    "de": true
});