define({
    "root": {
    	"details": "User details",
    	"navigation": "Users",
    	"delete": "Delete",
    	"save": "Save",
    	"name": "Name",
    	"username": "Username",
    	"email": "Email",
    	"role": "Role",
    	"password": "Password",
        "emptyMessage": "The user does not exist anymore",

        "newUser": "created a new user",
        "deleteUser": "deleted user",
        "updateUser": "updated user"
    },
    "de": true
});