define({
	"details": "Benutzer Details",
	"navigation": "Benutzer",
	"delete": "Löschen",
	"save": "Speichern",
	"name": "Name",
	"username": "Benutzername",
	"email": "Email",
	"role": "Benutzergruppe",
	"password": "Passwort",
    "emptyMessage": "Der Benutzer existiert nicht mehr",
    "confirmLogout": "Wirklich ausloggen?",
    "newUser": "hat Benutzer erstellt",
    "deleteUser": "hat Benutzer gelöscht",
    "updateUser": "hat Benutzer bearbeitet"
});