define({
    "root": {
    	"navigation": "Messages",
		"message": "Message",
	    "messagePlaceholder": "Send message...",
	    "send": "Send",
	    "clear": "Delete Messages",
	    "limit": "Limit Messages",
	    "nolimit": "All Messages",
	    "confirmClear": "Are you sure you want to delete all Messages?"
    },
    "de": true
});