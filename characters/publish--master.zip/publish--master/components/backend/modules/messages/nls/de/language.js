define({
	"navigation": "Nachrichten",
	"message": "Nachricht",
    "messagePlaceholder": "Nachricht senden...",
    "send": "Senden",
    "clear": "Nachrichten löschen",
    "limit": "Nachrichten anzeigen",
	"nolimit": "Alle Nachrichten",
	"confirmClear": "Willst du wirklich alle Nachrichten löschen?"
});