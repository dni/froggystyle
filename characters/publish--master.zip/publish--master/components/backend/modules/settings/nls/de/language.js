define({
	"headline": "Einstellungen",
	"deleteSetting": "hat Einstellung gelöscht",
	"updateSetting": "hat Einstellung aktualisiert",
	"fileDescription": "Template keys für icon generator sind 'logo','icon','background'",
	"clearCache": "App wird neu gestartet, kann einige Minuten dauern, bitte Daten speichern, sonst gehen sie verloren"

});