define({
	"root": {
		"headline": "Settings",
		"deleteSetting": "deleted setting",
		"fileDescription": "Use template keys for icon-generator 'logo','icon','background'",
		"updateSetting": "updated setting",
		"clearCache": "Rebuild and restart the app, this may take serveral minutes"
	},
	"de": true
});