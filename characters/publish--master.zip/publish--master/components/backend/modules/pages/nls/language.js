define({
    "root": {
    	"navigation": "Pages",
    	"addPage": "Add Page",
    	"layouts": "Layouts",
    	"number": "Number",
    	"publish": "Publish",
    	"unpublish": "Unpublish",
    	"details": "Page details",
        "title": "Title",
        "article": "Article",
        "newPage": "created new page",
        "updatePage": "updated page",
        "emptyMessage": "The page does not exist anymore",
        "deletePage": "deleted page"
    },
    "de": true
});