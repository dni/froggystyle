define({
	"pageHeadline": "Seiten",
    "addPage": "Seite hinzufügen",
	"navigation": "Seiten",
	"layouts": "Vorlagen",
	"details": "Seiten Details",
	"title": "Titel",
	"number": "Sortierung",
	"article": "Artikel",
	"newPage": "hat eine neue Seite erstellt",
    "updateMagazine": "hat eine Seite aktualisiert",
    "emptyMessage": "Die Seite existiert nicht mehr",
    "deleteMagazine": "hat eine Seite gelöscht"
});