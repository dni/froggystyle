require([
  'backbone',
  'cs!modules/blog/BlogModule'
], function(Backbone){
  Backbone.history.start();
});
