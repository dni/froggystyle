# Publish! Crossplattform Publishing
Publish your data on all channels!

## Support
The project was supported by aws - austria wirtschaftsservice
<a href="http://www.awsg.at/">http://www.awsg.at/</a>
